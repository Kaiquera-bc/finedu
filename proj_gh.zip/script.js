const courses = [
    {
        title: "Introdução ao Endividamento",
        stars: 5,
        content: [
            "Objetivo: Compreender as causas e consequências do endividamento",
            "Conteúdo:",
            "- O que é endividamento e superendividamento",
            "- Principais causas do endividamento no Brasil",
            "- Como identificar sinais de alerta financeiro",
            "- Diferença entre dívidas boas e ruins",
            "- Impactos do endividamento na vida pessoal e profissional",
            "- Primeiros passos para sair do endividamento"
        ]
    },
    {
        title: "Cartão de Crédito — Aliado ou Vilão?",
        stars: 4,
        content: [
            "Objetivo: Aprender a usar o cartão de crédito de forma consciente",
            "Conteúdo:",
            "- Funcionamento do cartão de crédito",
            "- Juros e taxas: entenda cada cobrança",
            "- Armadilhas comuns do cartão de crédito",
            "- Como usar o cartão a seu favor",
            "- Parcelamento: quando vale a pena?",
            "- Dicas para controlar os gastos no cartão",
            "- Cartão de crédito x Cartão de débito: quando usar cada um"
        ]
    },
    {
        title: "Direitos do Consumidor e Proteção contra Abusos",
        stars: 3,
        content: [
            "Objetivo: Conhecer seus direitos ao lidar com credores",
            "Conteúdo:",
            "- Direitos básicos do consumidor endividado",
            "- Práticas abusivas de cobrança e como identificá-las",
            "- Como proceder em caso de assédio dos credores",
            "- Órgãos de proteção ao consumidor e como acioná-los",
            "- Negativação indevida: como se defender",
            "- Renegociação de dívidas: seus direitos e deveres",
            "- Prescrição de dívidas: entenda como funciona"
        ]
    },
    {
        title: "Jogo de Apostas e Suas Armadilhas",
        stars: 3,
        content: [
            "Objetivo: Compreender os riscos das apostas e jogos de azar",
            "Conteúdo:",
            "- Psicologia por trás do vício em apostas",
            "- Sinais de comportamento compulsivo",
            "- Impactos financeiros das apostas",
            "- Mitos comuns sobre jogos de azar",
            "- Como o marketing das apostas funciona",
            "- Onde buscar ajuda para vício em apostas",
            "- Alternativas saudáveis para administrar seu dinheiro"
        ]
    },
    {
        title: "Lidando com Dívidas após Desemprego",
        stars: 1,
        content: [
            "Objetivo: Aprender estratégias para administrar dívidas durante o desemprego",
            "Conteúdo:",
            "- Priorização de pagamentos essenciais",
            "- Como negociar com credores durante o desemprego",
            "- Direitos do desempregado em relação a dívidas",
            "- Uso consciente do seguro-desemprego",
            "- Fontes de renda alternativa",
            "- Reorganização do orçamento familiar",
            "- Plano de ação para busca de recolocação"
        ]
    },
    {
        title: "Aspectos Psicológicos do Endividamento",
        stars: 1,
        content: [
            "Objetivo: Entender e lidar com o impacto emocional das dívidas",
            "Conteúdo:",
            "- Relação entre emoções e decisões financeiras",
            "- Ansiedade financeira: como identificar e lidar",
            "- Compulsão por gastos: causas e tratamento",
            "- Impacto das dívidas na saúde mental",
            "- Técnicas para controle do estresse financeiro",
            "- Como conversar sobre dívidas com a família",
            "- Onde buscar apoio psicológico"
        ]
    },
    {
        title: "Planejamento para Quitar Dívidas",
        stars: 3,
        content: [
            "Objetivo: Desenvolver um plano efetivo para sair das dívidas",
            "Conteúdo:",
            "- Como fazer um diagnóstico financeiro completo",
            "- Métodos para organizar e priorizar dívidas",
            "- Estratégias de negociação com credores",
            "- Criação de um cronograma de pagamentos",
            "- Técnicas para redução de gastos",
            "- Ferramentas para controle financeiro",
            "- Como evitar novas dívidas durante o processo"
        ]
    },
    {
        title: "Investindo em um fundo de emergência",
        stars: 4,
        content: [
            "Objetivo: Aprender a criar e manter uma reserva financeira de emergência",
            "Conteúdo:",
            "- O que é e para que serve um fundo de emergência",
            "- Como calcular o valor ideal do seu fundo",
            "- Melhores investimentos para reserva de emergência",
            "- Estratégias para construir seu fundo",
            "- Quando e como usar o fundo de emergência",
            "- Reposição do fundo após o uso",
            "- Dicas para acelerar a construção da reserva"
        ]
    }
];

function createStarRating(count, index) {
    const starsContainer = document.createElement('div');
    starsContainer.className = 'star-rating';
    starsContainer.dataset.courseIndex = index;

    for (let i = 1; i <= 5; i++) {
        const star = document.createElement('span');
        star.className = `fa fa-star star ${i <= count ? 'active' : 'star-empty'}`;
        star.dataset.rating = i;
        starsContainer.appendChild(star);
    }

    return starsContainer;
}

function updateStarRating(courseIndex, rating) {
    courses[courseIndex].stars = rating;
    const starContainer = document.querySelector(`.star-rating[data-course-index="${courseIndex}"]`);
    const stars = starContainer.getElementsByClassName('star');
    
    Array.from(stars).forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active');
            star.classList.remove('star-empty');
        } else {
            star.classList.remove('active');
            star.classList.add('star-empty');
        }
        
        star.classList.remove('selected');
        if (index === rating - 1) {
            star.classList.add('selected');
        }
    });

    localStorage.setItem('courseRatings', JSON.stringify(
        courses.map(course => ({ title: course.title, stars: course.stars }))
    ));
}

function createAccordionItem(course, index) {
    const objective = course.content.find(item => item.startsWith('Objetivo:'));
    const contentItems = course.content.filter(item => !item.startsWith('Objetivo:') && item !== 'Conteúdo:');
    
    const html = `
        <div class="course-item">
            <div class="course-header-wrapper">
                <button class="course-header collapsed flex-grow-1" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${index}">
                    <div class="d-flex justify-content-between align-items-center w-100">
                        <div class="course-title-section">
                            <span class="course-number">${String(index + 1).padStart(2, '0')}</span>
                            <span class="course-title">${course.title}</span>
                            ${objective ? `<p class="course-objective">${objective.replace('Objetivo: ', '')}</p>` : ''}
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="stars ms-2" id="stars-${index}"></div>
                            <i class="fa fa-chevron-down arrow ms-3"></i>
                        </div>
                    </div>
                </button>
            </div>
            <div id="collapse${index}" class="collapse" data-bs-parent="#courseAccordion">
                ${course.content.length ? `
                    <div class="course-content">
                        <div class="content-section">
                            <h3 class="content-title">Conteúdo do Módulo</h3>
                            <ul class="content-list">
                                ${contentItems.map(item => {
                                    if (item.startsWith('-')) {
                                        return `<li class="content-item">
                                            <i class="fa fa-check-circle me-2"></i>
                                            ${item.replace('- ', '')}
                                        </li>`;
                                    }
                                    return '';
                                }).filter(Boolean).join('')}
                            </ul>
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
    return html;
}

function loadSavedRatings() {
    const savedRatings = localStorage.getItem('courseRatings');
    if (savedRatings) {
        const ratings = JSON.parse(savedRatings);
        ratings.forEach(rating => {
            const courseIndex = courses.findIndex(course => course.title === rating.title);
            if (courseIndex !== -1) {
                courses[courseIndex].stars = rating.stars;
            }
        });
    }
}

function setupStarEvents() {
    document.querySelectorAll('.star-rating .star').forEach(star => {
        star.addEventListener('click', (e) => {
            e.stopPropagation(); // Previne que o clique propague para o accordion
            const rating = parseInt(e.target.dataset.rating);
            const courseIndex = parseInt(e.target.parentElement.dataset.courseIndex);
            updateStarRating(courseIndex, rating);
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadSavedRatings();
    
    const accordion = document.getElementById('courseAccordion');
    courses.forEach((course, index) => {
        accordion.innerHTML += createAccordionItem(course, index);
        
        // Add star rating after the HTML is inserted
        const starsContainer = document.getElementById(`stars-${index}`);
        starsContainer.appendChild(createStarRating(course.stars, index));
    });

    setupStarEvents();
});